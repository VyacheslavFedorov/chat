Thank you for purchasing this plugin.

If you have any questions, you can contact us at "support@cizimmedya.com" e-mail address.

Note: For SAAS product you must buy extended license.